clear;
clc;
close all;
%%
%case sample
sprofile=readmatrix('GSE79578.xlsx')
%%
%{
fpi=fopen('GSE79578.txt');  
hline1 = textscan(fpi, '%s', 1, 'delimiter', '\n');
field1=textscan(hline1{1}{1},'%s');
format='%s';   
for i=2:340
    format=[format,' %f'];    
end
slines =textscan(fpi, format,1000000,'delimiter', '\t');
sipi=slines{1};
sprofile = [];
for i = 2 :340
    sprofile = [sprofile, slines{i}];
end
fclose(fpi);
%}
%%
%stages
psize=size(sprofile);
stage_num=4;
case_num=[82,86,89,82];
tempcase(:,1:case_num(1),1)=sprofile(:,1:82);    % 0h    
tempcase(:,1:case_num(2),2)=sprofile(:,83:168);   % 12h
tempcase(:,1:case_num(3),3)=sprofile(:,169:257);  % 24h
tempcase(:,1:case_num(4),4)=sprofile(:,258:339);  % 48h
msize=size(tempcase);
tempcase=log(1+tempcase);
%%
%distribution
for t=1:stage_num
        for h=1:case_num(t)  
            for i=1:psize(1) 
             mu(i)=mean(tempcase(i,1:case_num(t),t));   
             sigma(i)=std(tempcase(i,1:case_num(t),t)); 
             casesimple_pdf(i,h,t)=normpdf(reshape(tempcase(i,h,t),1,1),mu(i),sigma(i)); 
             casesimple_cdf(i,h,t)=normcdf(reshape(tempcase(i,h,t),1,1),mu(i),sigma(i));  
            end
        end      
end
%%
for t=1:stage_num
        for i=1:(psize(1)-1) 
                for j=(i+1):psize(1)
                    if (mean(tempcase(i,:,t))==0)||(mean(tempcase(j,:,t))==0)
                        bnd_cdf(i,j,t)=0;
                    else
                        rou=corrcoef(tempcase(i,1:case_num(t),t),tempcase(j,1:case_num(t),t));
                        if  rou==1
                            bnd_cdf(i,j,t)=0;
                        else
                            syms u v;                
                            bnd_pdf=1./(2.*pi.*sigma(i).*sigma(j).*sqrt(1-rou(1,2).*rou(1,2))).*exp(-1./(2.*(1-rou(1,2).^2)).*[(u-mu(i)).*(u-mu(i))./(sigma(i).*sigma(i))-2.*rou(1,2).*(u-mu(i)).*(v-mu(j))./(sigma(i).*sigma(j))+(v-mu(j)).*(v-mu(j))./(sigma(j).*sigma(j))]);
                            bnd_pdff=matlabFunction(bnd_pdf);                     
                            bnd_cdf(i,j,t)=integral2(bnd_pdff,0,mean(tempcase(i,:,t)),0,mean(tempcase(j,:,t)));
                        end
                    end
                    disp(['Time' num2str(t) 'Gene' num2str(i) 'Gene' num2str(j) 'is completed']);
                end
        end
end
%%
%Construction of Mutual Infomation network
MI_network = cell(1,stage_num);
MI=zeros(psize(1),psize(1),stage_num);
W=zeros(psize(1),psize(1),stage_num);
for t=1:stage_num
    for i=1:(psize(1)-1) 
        for j=(i+1):psize(1)
            for h=1:case_num(t)
                if bnd_cdf(i,j,t)==0
                    MI(i,j,t)=0;
                else
                    a(h)=bnd_cdf(i,j,t).*log(bnd_cdf(i,j,t)./(casesimple_cdf(i,h,t).*casesimple_cdf(j,h,t)));
                    MI(i,j,t)=abs(sum(a));
                end
                MI(j,i,t)=MI(i,j,t);
                disp(['Time' num2str(t) 'Gene' num2str(i) 'Gene' num2str(j) 'is completed']);
            end
        end
    end
    MI_network{t}=MI(:,:,t);
end
%%
%Extracting local network
pretime=clock;
for c=1:length(MI_network)
    clear cell;
    clear cell_full_matrix;
    cell=MI_network{1,c};
    cell_full_matrix=full(cell);
    fid=fopen(['tmp_network',num2str(c),'_adj_edges_all.txt'],'wt');
    cell_full_size=size(cell_full_matrix);
    for i=1:cell_full_size(1)
        clear nei_node;
        clear node_expression;
        nei_node=find(cell_full_matrix(i,:)>0);
        if length(nei_node)==0 ||(sum(tempcase(i,:,c))==0)
            fprintf(fid,'%g\n',i);
            continue;
        end
        node_expression=mean(tempcase(nei_node,:,c));%节点表达值
        node_zero=find(node_expression==0);
        nei_node(node_zero)=[];
        if length(nei_node)==0
            fprintf(fid,'%g\n',i);
            continue;
        end
        for j=1:length(nei_node)
            if  j==length(nei_node)
                fprintf(fid,'%g\n',nei_node(j));
            else
                fprintf(fid,'%g\t',nei_node(j));
            end
        end
    end
    fclose(fid);
    currtime=clock;
    c,etime(currtime,pretime)
end
%%
%Calculate the gene differential entropy
DE=zeros(psize(1),stage_num)
for t=1:stage_num
    for i=1:psize(1) 
        if isnan(sigma(i))|isnan(mu(i))|mean(tempcase(i,:,t))==0
            DE(i,t)=0
        else
            syms y;                
            DE(i,t)=vpa(int((1./(sigma(i).*sqrt(2*pi)).*exp(-1./(2.*(sigma(i).^2)).*[(y-mu(i)).*(y-mu(i))])).*(log(1./(sigma(i).*sqrt(2*pi)).*exp(-1./(2.*(sigma(i).^2)).*[(y-mu(i)).*(y-mu(i))]))),0,mean(tempcase(i,:,t))));                     
        end
        disp(['time' num2str(t) 'gene' num2str(i) 'is completed']);
    end
end
%%
for t=1
    for i=psize(1)
        if isnan(DE(i,t))
           DE(i,t)=0;
        end
    end
end
%%
%Calculate the local weighted differential entropy
pretime=clock;
node_HT=zeros(psize(1),stage_num)
for c=1
    clear adjacent_network;
    fid=fopen(['tmp_network',num2str(c),'_adj_edges_all.txt']);
    adjacent_network={};
    j=0;
    while ~feof(fid)
        tline=fgetl(fid);
        j=j+1;
        adjacent_network{j}=regexp(tline, '\t', 'split');
    end
    fclose(fid);
    total_node_num=j;
    for na=1:total_node_num
        center=na;
        %cell_gene_name{c}{na}=sipi{center};
        e=0;
        clear p_rho;
        if (length(adjacent_network{na})==1)&&(str2num(adjacent_network{na}{1})==na)
            node_HT(na,c)=0;
        else
            for n=1:length(adjacent_network{na})
                nei=adjacent_network{na}{n};
                e=e+1;
                curr_weight= MI_network{c}(center,str2num(nei));
                node_HT(na,c)=node_HT(na,c)-(curr_weight*A(str2num(nei),1));
                disp(['time' num2str(c) 'na' num2str(na)  'n' num2str(n) 'is completed']);
            end  
        end
    end
    [node_sorted_HT,idx]=sort(node_HT(:,c));
    node_MAX_HT(:,c)=node_sorted_HT(total_node_num-total_node_num*0.05+1:total_node_num);
    currtime=clock;
    c,etime(currtime,pretime);
end
%%
weight_DE=mean(node_HT);
%%
%Visualization of images
combineData = [node_HT(:,1),node_HT(:,2),node_HT(:,3),node_HT(:,4)]; 
%group = [2*ones(50,1),3*ones(50,1),4*ones(50,1),5*ones(50,1),6*ones(50,1)]; 
boxplot(combineData);
hold on;
t=1:4;
plot(t,weight_DE,'r','LineWidth',3);
set(gca,'XTick',1:4);
B={'0h' '12h'  '24h' '48h'};
set(gca,'XTickLabel',B);
%set(gca,'yticklabel',[0:10]);
xlabel('Stage');
ylabel('MIWE');
%plot(t,aver_comidx,'r','LineWidth',3);
title('Average MIWE for mESC-to-MP data');