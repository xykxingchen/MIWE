clear;
clc;
close all;
%%
%生成仿真数据
e=exp(1);
for i=1:10  %network node
    X(i,1)=rand()*(5-1)+1;
end
delta_t=1;
L=2100;       
N=round(L/delta_t);  
ts=zeros(N,1);
sigma0=0.06;  %noise
es=0.000000001;
s0(1)=-0.5;
s0(2)=-0.475;
s0(3)=-0.45;
s0(4)=-0.4;
s0(5)=-0.375;
s0(6)=-0.35;
s0(7)=-0.325;
s0(8)=-0.3;
s0(9)=-0.275;
s0(10)=-0.25;
s0(11)=-0.225;
s0(12)=-0.2;
s0(13)=-0.175;
s0(14)=-0.15;
s0(15)=-0.125;
s0(16)=-0.1;
s0(17)=-0.08;
s0(18)=-0.05;
s0(19)=-0.02;
s0(20)=-0.0001;
s0(21)=0.02;
s0(22)=0.05;
s0(23)=0.08;
s0(24)=0.1;
s0(25)=0.15;
s0(26)=0.18;
s0(27)=0.22;
s0(28)=0.25;
D= [-1 0 1 0 0 0 0 0 0 0;...
    1 -1 0 0 0 0 0 0 0 0;...
    1 0 1 0 0 0 0 0 0 0;...
    1 0 0 -1 0 0 0 0 0 0;...
    -1 0 0 0 -1 0 0 0 0 0;...
    0 0 0 0 1 -1 1 0 0 0;...
    0 0 0 0 0 0 -1 1 0 0;...
    0 0 0 0 0 0 0 -1 -1 0;...
    0 0 0 0 0 0 0 1 -1 0;...
    0 0 0 0 0 0 0 1 -1 -1]; 
TT=20;
stage=28;
Score=zeros(stage,1);
T_global_MI=zeros(1,stage);
sample_num=1;
CC=zeros(10,4,sample_num);   
CC1=zeros(10,4,28);         
%for i=1:20
%    ss(i)=s(28-i);
%end
ss=-0.50:5/2700:-0.45;
%%
%1. reference samples
for ll=1:28
    qq(ll)=0.96^(1/abs(ss(ll)));  
    E=[-3/11*qq(ll) 0 0 0 0 0 0 0 0 0;...
            0 -6/11 0 0 0 0 0 0 0 0;...
            0  0 -8/11 0 0 0 0 0 0 0;...
            0 0 0 -10/11 0 0 0 0 0 0;...
            0 0 0 0 -12/11 0 0 0 0 0;...
            0 0 0 0 0 -14/11 0 0 0 0;...
            0 0 0 0 0 0 -16/11 0 0 0;...
            0 0 0 0 0 0 0 -18/11 0 0;...
            0 0 0 0 0 0 0 0 -20/11 0;...
            0 0 0 0 0 0 0 0 0 -22/11];  
    J=D*E*inv(D);   
    for i=1:N-1
        ts(i+1)=ts(i)+delta_t;  
        eJ=e^(J*delta_t);
        for jj=1:10
            X(jj,i+1)=eJ(jj,:)*X(:,i)+sigma0*normrnd(0,1)*delta_t;
        end
    end
    CC1(:,1,ll)=X(:,2000); 
stage=28;
pprofile=(reshape(CC1(:,1,:),10,28));
tempcontrol=abs(pprofile);
psize=size(tempcontrol);   
end
%2. case samples
tempcase=zeros(stage,10,29);% reference+1 case
patients_num=29;
%for T=1:TT
for t=1:28   
        q(t)=0.96^(1/abs(s0(t)));
         E=[-3/11*q(t) 0 0 0 0 0 0 0 0 0;...
            0 -6/11 0 0 0 0 0 0 0 0;...
            0  0 -8/11 0 0 0 0 0 0 0;...
            0 0 0 -10/11 0 0 0 0 0 0;...
            0 0 0 0 -12/11 0 0 0 0 0;...
            0 0 0 0 0 -14/11 0 0 0 0;...
            0 0 0 0 0 0 -16/11 0 0 0;...
            0 0 0 0 0 0 0 -18/11 0 0;...
            0 0 0 0 0 0 0 0 -20/11 0;...
            0 0 0 0 0 0 0 0 0 -22/11];  
        J=D*E*inv(D);        
        for k=1:sample_num
            for i=1:N-1
                ts(i+1)=ts(i)+delta_t;
                eJ=e^(J*delta_t);
                for jj=1:10
                    X(jj,i+1)=eJ(jj,:)*X(:,i)+sigma0*normrnd(0,1)*delta_t;
                end
            end
            CC(:,t,k)=X(:,2000);
        end
    TC(:,t)=reshape(CC(:,t,:),10,sample_num);
    tempcase(t,:,1:patients_num-1)=pprofile(:,1:psize(2)); 
    tempcase(t,:,patients_num)=TC(:,t); 
    tempcase=abs(tempcase);
end
%%
figure2=figure('NumberTitle', 'off', 'Name', 'Simulation');
axes2 = axes('Parent',figure2);
b=bar3(abs(TC));
for k=1:length(b)
    zdata=b(k).ZData;
    b(k).CData=zdata;
    b(k).FaceColor='interp';
end
set(gca,'XTick',1:28);
B={'-0.5' ' ' ' ' '-0.4 ' ' ' ' ' ' ' '-0.3 ' ' ' ' ' ' ' '-0.2' ' ' ' ' ' ' '-0.1' ' ' ' ' ' ' '0' ' ' ' ' ' ' '0.1' ' ' ' ' ' ' '0.2' ' '};
set(gca,'XTickLabel',B);
xlabel('Parameter');
ylabel('Nodes of network');
zlabel('Score');
%%
%stages
tempcase=permute(tempcase,[2,3,1])
psize=size(tempcase);
stage_num=28;
case_num=29*ones(1,28);
bnd_cdf=zeros(psize(1),psize(1),28);  
tempcase=log(1+tempcase);
%%
%distribution
for t=1:stage_num
        for h=1:case_num(t)  
            for i=1:psize(1) 
             mu(i)=mean(tempcase(i,1:case_num(t),t));   
             sigma(i)=std(tempcase(i,1:case_num(t),t)); 
             casesimple_pdf(i,h,t)=normpdf(reshape(tempcase(i,h,t),1,1),mu(i),sigma(i)); 
             casesimple_cdf(i,h,t)=normcdf(reshape(tempcase(i,h,t),1,1),mu(i),sigma(i));  
            end
        end      
end
%%
for t=1:stage_num
        for i=1:(psize(1)-1) 
                for j=(i+1):psize(1)
                    if (mean(tempcase(i,:,t))==0)||(mean(tempcase(i,:,t))==0)
                        bnd_cdf(i,j,t)=0;
                    else
                        rou=corrcoef(tempcase(i,1:case_num(t),t),tempcase(j,1:case_num(t),t));
                        syms u v;                
                        bnd_pdf=1./(2.*pi.*sigma(i).*sigma(j).*sqrt(1-rou(1,2).*rou(1,2))).*exp(-1./(2.*(1-rou(1,2).^2)).*[(u-mu(i)).*(u-mu(i))./(sigma(i).*sigma(i))-2.*rou(1,2).*(u-mu(i)).*(v-mu(j))./(sigma(i).*sigma(j))+(v-mu(j)).*(v-mu(j))./(sigma(j).*sigma(j))]);
                        bnd_pdff=matlabFunction(bnd_pdf);                     
                        bnd_cdf(i,j,t)=integral2(bnd_pdff,0,mean(tempcase(i,:,t)),0,mean(tempcase(j,:,t)));
                    end
                    disp(['Time' num2str(t) 'Gene' num2str(i) 'Gene' num2str(j) 'is completed']);
                end
        end
end
%%
%Construction of Mutual Infomation network
MI_network = cell(1,stage_num);
MI=zeros(psize(1),psize(1),stage_num);
W=zeros(psize(1),psize(1),stage_num);
for t=1:stage_num
    for i=1:(psize(1)-1) 
        for j=(i+1):psize(1)
            for h=1:case_num(t)
                if bnd_cdf(i,j,t)==0
                    MI(i,j,t)=0;
                else
                    a(h)=bnd_cdf(i,j,t).*log(bnd_cdf(i,j,t)./(casesimple_cdf(i,h,t).*casesimple_cdf(j,h,t)));
                    MI(i,j,t)=abs(sum(a));
                end
                MI(j,i,t)=MI(i,j,t);
                disp(['Time' num2str(t) 'Gene' num2str(i) 'Gene' num2str(j) 'is completed']);
            end
        end
    end
    MI_network{t}=MI(:,:,t);
end
%%
%Extracting local network
pretime=clock;
for c=1:length(MI_network)
    clear cell;
    clear cell_full_matrix;
    cell=MI_network{1,c};
    cell_full_matrix=full(cell);
    fid=fopen(['tmp_network',num2str(c),'_adj_edges_all.txt'],'wt');
    cell_full_size=size(cell_full_matrix);
    for i=1:cell_full_size(1)
        clear nei_node;
        clear node_expression;
        nei_node=find(cell_full_matrix(i,:)>0);
        if length(nei_node)==0 ||(sum(tempcase(i,:,c))==0)
            fprintf(fid,'%g\n',i);
            continue;
        end
        node_expression=mean(tempcase(nei_node,:,c));%节点表达值
        node_zero=find(node_expression==0);
        nei_node(node_zero)=[];
        if length(nei_node)==0
            fprintf(fid,'%g\n',i);
            continue;
        end
        for j=1:length(nei_node)
            if  j==length(nei_node)
                fprintf(fid,'%g\n',nei_node(j));
            else
                fprintf(fid,'%g\t',nei_node(j));
            end
        end
    end
    fclose(fid);
    currtime=clock;
    c,etime(currtime,pretime)
end
%%
%Calculate the gene differential entropy
DE=zeros(psize(1),stage_num)
for t=1:stage_num
    for i=1:psize(1) 
        syms y;                
        DE(i,t)=vpa(int((1./(sigma(i).*sqrt(2*pi)).*exp(-1./(2.*(sigma(i).^2)).*[(y-mu(i)).*(y-mu(i))])).*(log(1./(sigma(i).*sqrt(2*pi)).*exp(-1./(2.*(sigma(i).^2)).*[(y-mu(i)).*(y-mu(i))]))),0,mean(tempcase(i,:,t))));                     
        disp(['time' num2str(t) 'gene' num2str(i) 'is completed']);
    end
end
%%
%Calculate the local weighted differential entropy
pretime=clock;
node_HT=zeros(psize(1),stage_num)
for c=1:length(MI_network)
    clear adjacent_network;
    fid=fopen(['tmp_network',num2str(c),'_adj_edges_all.txt']);
    adjacent_network={};
    j=0;
    while ~feof(fid)
        tline=fgetl(fid);
        j=j+1;
        adjacent_network{j}=regexp(tline, '\t', 'split');
    end
    fclose(fid);
    total_node_num=j;
    for na=1:total_node_num
        center=na;
        e=0;
        clear p_rho;
        if (length(adjacent_network{na})==1)&&(str2num(adjacent_network{na}{1})==na)
            node_HT(na,c)=0;
        else
            for n=1:length(adjacent_network{na})
                nei=adjacent_network{na}{n};
                e=e+1;
                curr_weight= MI_network{c}(center,str2num(nei));
                node_HT(na,c)=node_HT(na,c)-(curr_weight*DE(str2num(nei),c));
                disp(['time' num2str(c) 'na' num2str(na)  'n' num2str(n) 'is completed']);
            end 
        end
    end
    [node_sorted_HT,idx]=sort(node_HT(:,c));
    weight_DE(c)=mean(node_sorted_HT);
    currtime=clock;
    c,etime(currtime,pretime);
    disp(['Time' num2str(c) 'is completed']);
end
%%
weight_DE=abs(weight_DE)
figure1=figure('NumberTitle', 'off', 'Name', 'Simulation');
axes1 = axes('Parent',figure1);
plot(s0(1:28),weight_DE,'r-*','LineWidth',2.5);
line([s0(20) s0(20)],[0 weight_DE(20)],'linestyle','--','Color','m','LineWidth',1.5);
xlim(axes1,[-0.5 0.25]);
ylim(axes1,[0 25]);
box(axes1,'on');
xlabel('Parameter p');
ylabel('Score');

figure2=figure('NumberTitle', 'off', 'Name', 'Simulation');
axes2 = axes('Parent',figure2);
b=bar3(abs(node_HT));
for k=1:length(b)
    zdata=b(k).ZData;
    b(k).CData=zdata;
    b(k).FaceColor='interp';
end
set(gca,'XTick',1:28);
B={'-0.5' ' ' ' ' '-0.4 ' ' ' ' ' ' ' '-0.3 ' ' ' ' ' ' ' '-0.2' ' ' ' ' ' ' '-0.1' ' ' ' ' ' ' '0' ' ' ' ' ' ' '0.1' ' ' ' ' ' ' '0.2' ' '};
set(gca,'XTickLabel',B);
xlabel('Parameter');
ylabel('Nodes of network');
zlabel('Score');

